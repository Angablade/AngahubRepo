(function () {
  "use strict";
  if (typeof registerWidget !== "function") return;

  const API_BASE = "/api/windy-radar";
  const esc = (value) => {
    if (typeof window.esc === "function") return window.esc(String(value ?? ""));
    return String(value ?? "").replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
  };

  registerWidget({
    id: "com.angahub.windy-radar",
    name: "Windy Radar",
    description: "Live Windy.com radar for a ZIP code.",
    defaultEnabled: false,
    mount(el, opts) {
      el.classList.add("widget", "windy-radar-widget");
      const savedZip = String(
        opts?.settings?.windy_radar_zip ??
        window.AngaHub?.getPluginApi?.()?.getSettings?.()?.windy_radar_zip ??
        ""
      ).trim();

      el.innerHTML = `
        <style>
          .windy-radar-widget { min-width: 0; }
          .wr-head { display:flex; align-items:center; justify-content:space-between; gap:.5rem; }
          .wr-title { font-weight:700; }
          .wr-controls { display:flex; gap:.4rem; margin:.55rem 0; }
          .wr-zip { min-width:0; width:7.5rem; flex:1; }
          .wr-frame { position:relative; width:100%; aspect-ratio:16/10; min-height:180px; overflow:hidden; border-radius:10px; background:#101820; }
          .wr-frame iframe { position:absolute; inset:0; width:100%; height:100%; border:0; }
          .wr-status { margin:.35rem 0; font-size:.85rem; opacity:.8; }
          .wr-btn { cursor:pointer; }
          .wr-map-link { font-size:.85rem; }
          @media (prefers-reduced-motion: reduce) { .windy-radar-widget * { scroll-behavior:auto !important; } }
        </style>
        <div class="wr-head"><div class="wr-title">Windy Radar</div><a class="wr-map-link" target="_blank" rel="noopener noreferrer" href="https://www.windy.com/">Open Windy ↗</a></div>
        <form class="wr-controls">
          <input class="wr-zip" aria-label="US ZIP code" inputmode="numeric" autocomplete="postal-code" maxlength="5" pattern="[0-9]{5}" placeholder="ZIP code" value="${esc(savedZip)}">
          <button class="primary wr-btn" type="submit">Show radar</button>
        </form>
        <div class="wr-status" role="status" aria-live="polite">Enter a US ZIP code to load radar.</div>
        <div class="wr-frame"><div class="wr-placeholder" style="padding:1rem;opacity:.75">Radar map will appear here.</div></div>
      `;

      const form = el.querySelector("form");
      const input = el.querySelector(".wr-zip");
      const status = el.querySelector(".wr-status");
      const frame = el.querySelector(".wr-frame");
      let currentController = null;
      let requestSeq = 0;

      async function loadRadar(zip, persist) {
        zip = String(zip || "").trim();
        if (!/^\d{5}$/.test(zip)) {
          status.textContent = "Enter a valid 5-digit US ZIP code.";
          input.focus();
          return;
        }
        const seq = ++requestSeq;
        status.textContent = "Finding ZIP code…";
        frame.replaceChildren();
        const placeholder = document.createElement("div");
        placeholder.style.cssText = "padding:1rem;opacity:.75";
        placeholder.textContent = "Loading radar map…";
        frame.appendChild(placeholder);

        try {
          const api = window.AngaHub?.getPluginApi?.();
          let result;
          if (api?.api) {
            result = await api.api(`${API_BASE}/location/${encodeURIComponent(zip)}`);
          } else {
            const response = await fetch(`${API_BASE}/location/${encodeURIComponent(zip)}`, { signal: currentController?.signal });
            if (!response.ok) throw new Error(`ZIP lookup failed (${response.status})`);
            result = await response.json();
          }
          if (seq !== requestSeq) return;
          const lat = Number(result.latitude);
          const lon = Number(result.longitude);
          if (!Number.isFinite(lat) || !Number.isFinite(lon)) throw new Error("ZIP lookup returned invalid coordinates.");

          const iframe = document.createElement("iframe");
          iframe.title = `Windy weather radar near ${result.place || zip}, ${result.state || ""}`;
          iframe.loading = "lazy";
          iframe.referrerPolicy = "strict-origin-when-cross-origin";
          iframe.allow = "fullscreen";
          iframe.src = `https://embed.windy.com/embed2.html?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&detailLat=${encodeURIComponent(lat)}&detailLon=${encodeURIComponent(lon)}&width=650&height=450&zoom=7&level=surface&overlay=radar&product=radar&menu=&message=true&marker=true&calendar=now&pressure=&type=map&location=coordinates&metricRain=in&metricTemp=%C2%B0F&metricWind=mph`;
          frame.replaceChildren(iframe);
          status.textContent = `Radar centered near ${result.place || zip}${result.state ? ", " + result.state : ""} (${zip}).`;
          if (persist && api?.api) {
            try {
              await api.api("/api/settings", {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ windy_radar_zip: zip })
              });
            } catch (_) { /* Widget remains usable if settings persistence is unavailable. */ }
          }
        } catch (err) {
          if (seq !== requestSeq) return;
          status.textContent = String(err?.message || err || "Unable to load radar.");
          frame.replaceChildren();
          const fallback = document.createElement("div");
          fallback.style.cssText = "padding:1rem";
          fallback.textContent = "ZIP lookup failed. Check the ZIP and network connection, then try again.";
          frame.appendChild(fallback);
        }
      }

      form.addEventListener("submit", (event) => {
        event.preventDefault();
        loadRadar(input.value, true);
      });
      if (savedZip) loadRadar(savedZip, false);
    },
    unmount(el) {
      const frame = el.querySelector(".wr-frame");
      if (frame) frame.replaceChildren();
    }
  });
})();
