"""Backend ZIP-code lookup for the AngaHub Windy Radar widget."""
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
import json
import re

from fastapi import APIRouter, HTTPException

router = APIRouter(prefix="/api/windy-radar", tags=["windy-radar"])


def _lookup_zip(zip_code: str) -> dict:
    if not re.fullmatch(r"\d{5}", zip_code):
        raise HTTPException(status_code=400, detail="ZIP code must be exactly five digits.")

    url = f"https://api.zippopotam.us/us/{zip_code}"
    request = Request(url, headers={"User-Agent": "AngaHub-Windy-Radar/1.0"})
    try:
        with urlopen(request, timeout=5) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        if exc.code == 404:
            raise HTTPException(status_code=404, detail="That ZIP code was not found.") from exc
        raise HTTPException(status_code=502, detail="ZIP lookup service returned an error.") from exc
    except (URLError, TimeoutError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=502, detail="Could not reach the ZIP lookup service.") from exc

    places = payload.get("places") or []
    if not places:
        raise HTTPException(status_code=404, detail="No location was found for that ZIP code.")
    place = places[0]
    try:
        latitude = float(place["latitude"])
        longitude = float(place["longitude"])
    except (KeyError, TypeError, ValueError) as exc:
        raise HTTPException(status_code=502, detail="ZIP lookup returned invalid coordinates.") from exc

    return {
        "zip": zip_code,
        "place": place.get("place name", ""),
        "state": place.get("state abbreviation", place.get("state", "")),
        "latitude": latitude,
        "longitude": longitude,
    }


@router.get("/location/{zip_code}")
def location(zip_code: str):
    """Resolve a five-digit US ZIP code to a place and map coordinates."""
    return _lookup_zip(zip_code)


def register(app, register_service=None):
    """AngaHub Python plugin entry point."""
    app.include_router(router)
