# AngaHub Windy Radar Widget

A home-screen widget that accepts a five-digit US ZIP code, resolves it to coordinates, and embeds Windy.com's radar map centered on that location.

## Package contents

- `manifest.json` — AngaHub package manifest (`kind: widget`, API v1).
- `plugin.js` — widget UI and Windy radar iframe.
- `plugin.py` — FastAPI route `/api/windy-radar/location/{zip_code}`; looks up ZIP coordinates through Zippopotam.us.

## Install

1. In AngaHub's Plugin Store, install this ZIP if your store supports local package upload, or extract the package using the local/store package workflow documented by your AngaHub build.
2. Confirm the JavaScript entry is installed in the widgets directory and the Python backend is loaded by the host.
3. Restart/reload the AngaHub backend after installing `plugin.py`, then hard-refresh the frontend.
4. Enable **Windy Radar** in the home widget settings.
5. Enter a five-digit US ZIP code and select **Show radar**.

## Network requirements

- AngaHub backend must be able to reach `api.zippopotam.us` over HTTPS.
- The browser must be able to load `embed.windy.com`.
- Windy is embedded from Windy's public embed URL; availability and map behavior are subject to Windy's own service, terms, and embed support.
- ZIP lookup is US-only. The location is the ZIP's representative point, not necessarily a precise street address.

## Notes

- The widget saves the most recently submitted ZIP to the shared AngaHub settings object as `windy_radar_zip`.
- No Windy API key is included or required by this implementation.
- If the host's widget `mount(el, opts)` does not pass settings in `opts`, the widget reads them from `AngaHub.getPluginApi().getSettings()` when available.
